<?php
//About Us Area
function monalisa_about_us_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
            'about_section_img' => '',                   
            'about_title' => 'About our <span>Monalisa</span>',                   
            'about_content' => '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis magnam ea necessitatibus, officiis voluptas odit! Aperiam omnis, cupiditate laudantium velit nostrum, exercitationem accusamus, possimus soluta illo.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis magnam ea necessitatibus, officiis voluptas odit.</p>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Excepturi perferendis magnam ea necessitatibus, officiis voluptas odit! Aperiam omnis, cupiditate laudantium velit nostrum.</p>
						',                   

		), $atts )
    );
ob_start();
$about_section_img = wp_get_attachment_image_src($about_section_img,'');
?>

<!-- START ABOUT US -->	
<section id="about" class="about-us section-padding">
	<div class="container">
		<div class="row">	
			<div class="col-md-6 col-sm-12 col-xs-12">
				<div class="about_img">	
					<img src="<?php echo esc_url($about_section_img['0']);?>" class="img-responsive" alt="" />  
				</div>
			</div><!-- END COL -->					
			<div class="col-md-6 col-sm-12 col-xs-12">
				<div class="about-us-content">
					<h2><?php echo monalisa_wp_kses($about_title);?></h2>
					<div class="about-line"></div>
					<?php echo monalisa_wp_kses($about_content);?>
				</div>
			</div><!-- END COL -->
		</div><!-- END ROW -->
	</div><!-- END CONTAINER -->
</section>
<!-- END ABOUT US -->
		
<?php 
  return ob_get_clean();
}
add_shortcode ('about_us_area', 'monalisa_about_us_area' );

//Why Choose us Area
function monalisa_why_choose_us_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
            'section_title' => 'Why Choose <span>Monalisa</span>',                                    
            'section_content' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.',                   
            'section_image' => '',                   

		), $atts )
    );
ob_start();
$section_image = wp_get_attachment_image_src($section_image,'');
?>

	<!-- START WHY CHOOSE US -->
		<section class="why_choose_us section-padding">
			<div class="container">
				<div class="row">
					<div class="section-title text-center wow zoomIn">
						<h2><?php echo monalisa_wp_kses($section_title);?></h2>
						<div class="line"></div>
						<p><?php echo monalisa_wp_kses($section_content);?></p>
					</div>					
					<div class="col-md-6 col-sm-6 col-xs-12">
						<div id="why_choose">
							<!-- Wrapper for slides -->
							<div class="row ">	
							<?php echo do_shortcode($content);?>
							</div><!-- END CAROUSEL INNER -->
						</div><!-- END CAROUSEL SLIDE -->				
					</div><!--- END COL -->
					<div class="col-md-6 col-sm-6 col-xs-12"> 
						<div class="feature_img">
							<img src="<?php echo esc_url($section_image['0']);?>" alt="" />
						</div>
					</div><!--- END COL -->						
				</div><!--- END ROW -->			
			</div><!--- END CONTAINER -->		
		</section>
		<!-- END WHY CHOOSE US -->
		
<?php 
  return ob_get_clean();
}
add_shortcode ('why_choose_us_area', 'monalisa_why_choose_us_area' );

//Why Choose us Item
function monalisa_why_choose_us_item( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
            'choose_icon' => 'fa fa-lemon-o',                                    
            'choose_title' => 'Xoss Environment',                                    
            'choose_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras interdum ante vel aliquet euismod. ',                                    

		), $atts )
    );
ob_start();

?>

<div class="col-sm-6">
	<div class="single_feature">
		<i class="<?php echo esc_attr($choose_icon);?>"></i>
		<h3><?php echo esc_html($choose_title);?></h3>
		<span></span>
		<p><?php echo monalisa_wp_kses($choose_content);?></p>
	</div>
</div><!-- END col-sm-6 -->
		
<?php 
  return ob_get_clean();
}
add_shortcode ('why_choose_us_item', 'monalisa_why_choose_us_item' );

//Counter Area
function monalisa_counter_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
            'counter_bg' => '',                                    
		), $atts )
    );
ob_start();
$counter_bg = wp_get_attachment_image_src($counter_bg,'');
?>

<!-- START COUNT DOWN DESIGN --> 
<section  id="counter_item" class="counter section-padding" style="background-image: url(<?php echo esc_url($counter_bg[0]);?>);  background-size:cover; background-position: center center;background-attachment:fixed;">
	<div class="container">
		  <div class="row count text-center">
			<?php echo do_shortcode($content);?>
		  </div><!--- END ROW -->
	</div><!--- END CONTAINER -->
 </section>
<!-- END COUNT DOWN DESIGN --> 
		
<?php 
  return ob_get_clean();
}
add_shortcode ('counter_area', 'monalisa_counter_area' );

//Counter Item Area
function monalisa_counter_item_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
            'counter_number' => '140',                                    
            'counter_text' => 'Awards won',                                    
		), $atts )
    );
ob_start();

?>

	<div class="col-sm-3 col-xs-12 wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="300ms">
		<div class="timer">
			<h2 class="time_counter"><?php echo esc_html($counter_number);?></h2>
			<p class="counter_title"><?php echo esc_html($counter_text);?></p>
		</div>
	</div><!--- END COL -->
<?php 
  return ob_get_clean();
}
add_shortcode ('counter_item_area', 'monalisa_counter_item_area' );

//gallery Area
function monalisa_gallery_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
			'section_title' => 'Monalisa <span>Gallery</span>',                                    
            'section_content' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.',                   
            'section_btn_text' => 'See More Projects',                   
            'section_btn_link' => '#',                   
                                               
		), $atts )
    );
ob_start();

?>

<!-- START PORTFOLIO -->
<section id="gallery" class="works_area section-padding">		
	<div class="container-fluid">
		<div class="row text-center">
			<div class="section-title wow zoomIn">
				<h2><?php echo monalisa_wp_kses($section_title);?></h2>
				<div class="line"></div>
				<p><?php echo monalisa_wp_kses($section_content);?></p>
			</div>
			
				<?php
					// WP_Query arguments
					$args = array(
						'post_type'              => array( 'gallery' ),
						'posts_per_page'         => '8',
					);

					// The Query
					$molaisa_gallery_query = new WP_Query( $args );

					// The Loop
					if ( $molaisa_gallery_query->have_posts() ) {
						while ( $molaisa_gallery_query->have_posts() ) {
							$molaisa_gallery_query->the_post(); 
							$molaisa_gallery_img = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),'monalisa_image_770_510'); 
							?>
							<div class="col-md-3 col-sm-3 col-xs-12 no-padding">
								<div class="grid">
									<figure class="effect-apollo">
									<?php the_post_thumbnail('monalisa_image_770_510', array('class' => 'img-responsive')); ?>
							
										<figcaption>
											<a class="prettyPhoto image_zoom" href="<?php echo esc_url($molaisa_gallery_img[0]);?>"></a>
											<p><a href="<?php the_permalink();?>" data-toggle="modal" data-target="#projectModal"><?php the_title();?></a></p>
										</figcaption>
									</figure>
								</div>
							</div><!--- END COL -->
					<?php	}
					} else {
						// no posts found
					}

					// Restore original Post Data
				wp_reset_postdata();
				?>			


		</div><!--- END ROW -->
		<?php if($section_btn_link){ ?>
			<div class="portfolio_btn text-center">
				<a href="<?php echo esc_url($section_btn_link);?>" class="btn btn-default btn-portfolio-bg"><?php echo esc_html($section_btn_text);?></a>
			</div>
		<?php } ?>
	</div><!--- END CONTAINER-FLUID -->			
</section>
<!-- END PORTFOLIO -->
<?php 
  return ob_get_clean();
}
add_shortcode ('gallery_area', 'monalisa_gallery_area' );

//Offer Area
function monalisa_offer_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
			'section_title' => 'Get your special offer today',                                    
            'section_content' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet. when an unknown printer took a galley of type and scrambled it to make a type specimen book.',                   
            'section_btn_text' => 'Make an appointment',                   
            'section_btn_link' => '#',                   
                                               
		), $atts )
    );
ob_start();

?>

<div class="offer">
	<h3><?php echo esc_html($section_title);?></h3>
	<p><?php echo monalisa_wp_kses($section_content);?></p>
	<?php if($section_btn_link){ ?>
		<a href="<?php echo esc_html($section_btn_link);?>"><?php echo esc_html($section_btn_text);?></a>
	<?php } ?>
</div>
<?php 
  return ob_get_clean();
}
add_shortcode ('offer_area', 'monalisa_offer_area' );

//Opening Hours Area
function monalisa_opening_hour_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
			'section_title' => 'Monalisa Open Hours',                                    
            'section_content' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation.',                                   
                                               
		), $atts )
    );
ob_start();

?>

	<div class="opening_hour">
		<h3><?php echo esc_html($section_title);?></h3>
		<p><?php echo monalisa_wp_kses($section_content);?></p>
		<ul>
			<?php echo do_shortcode($content);?>
		</ul>
	</div>
<?php 
  return ob_get_clean();
}
add_shortcode ('opening_hour_area', 'monalisa_opening_hour_area' );

//Opening Hours Item
function monalisa_opening_hour_item( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
			'oh_day' => 'Monday-Friday',                                    
            'oh_time' => '8.00AM - 5.00PM',                                   
                                               
		), $atts )
    );
ob_start();

?>
	<li><?php echo esc_html($oh_day);?> <span><?php echo esc_html($oh_time);?></span></li>
<?php 
  return ob_get_clean();
}
add_shortcode ('opening_hour_item', 'monalisa_opening_hour_item' );

//Feature Area
function monalisa_feature_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
			'section_title' => 'Monalisa <span>Features</span>',                                    
			'section_subtitle' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.',                                    
			'section_number_post' => '3',                                    
                                
                                               
		), $atts )
    );
ob_start();

?>
<!-- START FEATURE -->
<section id="feature" class="our_offer section-padding">
	<div class="container">
		<div class="row text-center">
			<div class="section-title">
				<h2><?php echo monalisa_wp_kses($section_title);?></h2>
				<div class="line"></div>
				<p><?php echo monalisa_wp_kses($section_subtitle);?></p>
			</div>
			
			<?php 
					// WP_Query arguments
					$args = array(
						'post_type'              => array( 'feature' ),
						'posts_per_page'         => $section_number_post,
					);

					// The Query
					$feature_query = new WP_Query( $args );

					// The Loop
					if ( $feature_query->have_posts() ) {
						while ( $feature_query->have_posts() ) {
							$feature_query->the_post(); 
							$monalisa_feature_price = get_post_meta(get_the_ID(), '_monalisa_feature_price', true);
							$monalisa_feature_btn_text = get_post_meta(get_the_ID(), '_monalisa_feature_btn_text', true);
							$monalisa_feature_link = get_post_meta(get_the_ID(), '_monalisa_feature_link', true);
							?>
							
							<div class="col-md-4 col-sm-4 col-xs-12">
								<div class="single_offer">
									<div class="single_offer_img">
										<?php the_post_thumbnail('monalisa_image_1280_500', array('class' => 'img-responsive')); ?>
									</div>
									<h4><?php the_title();?></h4>
									<h5><?php echo esc_html($monalisa_feature_price);?></h5>
									<a class="btn btn-default btn-feature-bg" href="<?php echo esc_url($monalisa_feature_link);?>"><?php echo esc_html($monalisa_feature_btn_text);?></a>
								</div>	
							</div><!-- END COL -->
			
					<?php	}
					} else {
						// no posts found
					}

					// Restore original Post Data
					wp_reset_postdata();
			?>			

		</div><!-- END ROW -->
	</div><!-- END CONTAINER -->
</section>
<!-- END FEATURE -->
<?php 
  return ob_get_clean();
}
add_shortcode ('feature_area', 'monalisa_feature_area' );

//Team Area
function monalisa_team_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
			'section_title' => 'Monalisa <span>Lovely</span> Team',                                    
			'section_subtitle' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.',                                    
			'section_number_post' => '4',                                    
                                
                                               
		), $atts )
    );
ob_start();

?>

<!-- START TEAM -->
<section id="team" class="our_team section-padding">
	<div class="container">		
		<div class="row text-center">
			<div class="section-title wow zoomIn">
				<h2><?php echo monalisa_wp_kses($section_title);?></h2>
				<div class="line"></div>
				<p><?php echo monalisa_wp_kses($section_subtitle);?></p>
			</div>		

			<?php
				// WP_Query arguments
				$args = array(
					'post_type'              => array( 'team' ),
					'posts_per_page'         => $section_number_post,
				);

				// The Query
				$monalisa_team_query = new WP_Query( $args );

				// The Loop
				if ( $monalisa_team_query->have_posts() ) {
					while ( $monalisa_team_query->have_posts() ) {
						$monalisa_team_query->the_post(); 
						$monalisa_team_designation = get_post_meta(get_the_ID(), '_monalisa_team_designation', true);
						$monalisa_team_group_field_opt = get_post_meta(get_the_ID(), '_monalisa_team_group_field_opt', true);
						
						?>
							<div class="col-md-3 col-sm-6">
								<div class="single_team">
									<div class="img_wrap">
										<?php the_post_thumbnail('monalisa_image_870_984', array('class' => 'img-responsive')); ?>
										<div class="social_link">
											<div class="social_table">
												<ul class="list-inline">
												<?php
													foreach ( (array) $monalisa_team_group_field_opt as $key => $team_entry ) {

														$social_icon = $social_link = '';

														if ( isset( $team_entry['_monalisa_social_icon'] ) )
															$social_icon = $team_entry['_monalisa_social_icon'];

														if ( isset( $team_entry['_monalisa_social_link'] ) )
															$social_link = $team_entry['_monalisa_social_link'];	

														?>
														
															<li><a href="<?php echo esc_url($social_link);?>"><i class="fa <?php echo esc_attr($social_icon);?>"></i></a></li>
													
													<?php } ?>												
													

												</ul>
											</div>
										</div>
									</div>
									<h3><?php the_title();?></h3>
									<h4><?php echo esc_html($monalisa_team_designation);?></h4>							
								</div>
							</div><!-- END COL -->	
				<?php	}
				} else {
					// no posts found
				}

				// Restore original Post Data
				wp_reset_postdata();
			?>			

			
		</div><!-- END ROW  -->
	</div><!-- END CONTAINER  -->
</section>
<!-- END TEAM -->	
		
<?php 
  return ob_get_clean();
}
add_shortcode ('team_area', 'monalisa_team_area' );

//Video Area
function monalisa_video_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
			'vid_bg' => '',                                                                                                     
			'vid_title' => 'How it works',                                                                                                     
			'vid_url' => 'https://www.youtube.com/embed/vR9mzDjmS7M',                                                                                                     
                                               
		), $atts )
    );
ob_start();
$vid_bg = wp_get_attachment_image_src($vid_bg,'');
?>

<!-- START HOW IT WORKS -->
<section data-stellar-background-ratio="0.3" id="how_it_works" class="about_video" style="background-image: url(<?php echo esc_url($vid_bg[0]);?>); background-size:cover; background-position: center center;">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12 text-center">
				<div class="video-container">                  
					<h3><?php echo esc_html($vid_title);?></h3>
					<a data-toggle="modal" data-target="#video-modal" data-backdrop="true">
					<span class="play-video"><span class="fa fa-play"></span></span></a>
				</div>
				<!-- VIDEO POPUP -->
				<div class="modal fade video-modal" id="video-modal" role="dialog">
					<div class="modal-content">
						<iframe width="712" height="400" src="<?php echo esc_url($vid_url);?>"></iframe>
					</div>
				</div>
				<!-- END VIDEO POPUP -->	
			</div><!--- END COL -->					
		</div><!--- END ROW -->
	</div><!--- END CONTAINER -->	
</section>
<!-- END HOW IT WORKS -->
		
<?php 
  return ob_get_clean();
}
add_shortcode ('video_area', 'monalisa_video_area' );

//Pricing Area
function monalisa_pricing_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
			'section_title' => 'Monalisa <span>Pricing</span>',                                                                                                                                                                                                         
			'section_subtitle' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.',                                                                                                                                                                                                         
			'section_number_post' => '3',                                                                                                                                                                                                         
                                               
		), $atts )
    );
ob_start();
?>

<!-- START PRICING -->
<section id="pricing" class="pricing_table section-padding">
	<div class="container">
		<div class="row text-center">
			<div class="section-title wow zoomIn">
				<h2><?php echo monalisa_wp_kses($section_title);?></h2>
				<div class="line"></div>
				<p><?php echo monalisa_wp_kses($section_subtitle);?></p>
			</div>	
			
				<?php
					// WP_Query arguments
					$args = array(
						'post_type'              => array( 'pricing' ),
						'posts_per_page'         => $section_number_post,
					);

					// The Query
					$monalisa_pricing_query = new WP_Query( $args );

					// The Loop
					if ( $monalisa_pricing_query->have_posts() ) {
						while ( $monalisa_pricing_query->have_posts() ) {
							$monalisa_pricing_query->the_post(); 
							$monalisa_pricing_feature_item = get_post_meta(get_the_ID(), '_monalisa_pricing_feature_item', true);
							$monalisa_pricing_amount = get_post_meta(get_the_ID(), '_monalisa_pricing_amount', true);
							$monalisa_pricing_period = get_post_meta(get_the_ID(), '_monalisa_pricing_period', true);
							$monalisa_pricing_group_field_opt = get_post_meta(get_the_ID(), '_monalisa_pricing_group_field_opt', true);
							$monalisa_pricing_btn_text = get_post_meta(get_the_ID(), '_monalisa_pricing_btn_text', true);
							$monalisa_pricing_btn_link = get_post_meta(get_the_ID(), '_monalisa_pricing_btn_link', true);
						
							?>
							
							<div class="col-md-4 col-sm-4 col-xs-12">
								<div class="pricing-table">
									
									<div class="price <?php if($monalisa_pricing_feature_item){ echo esc_attr('color-two');}else{ echo esc_attr('color-one');}?>">
										<h3><?php the_title();?></h3>
										<span><?php echo esc_html($monalisa_pricing_amount);?></span>
										<div class="price-period"><?php echo esc_html($monalisa_pricing_period);?></div>
									</div>
									<ul class="pricing-list">
										<?php
											foreach ( (array) $monalisa_pricing_group_field_opt as $key => $pricing_entry ) {

												$single_feature = '';

												if ( isset( $pricing_entry['_monalisa_single_feature'] ) )
													$single_feature = $pricing_entry['_monalisa_single_feature'];	

												?>
												
													<li><?php echo esc_html($single_feature);?></li>
											
											<?php } ?>											
									</ul>
									<div class="pricing-btn">
										<a href="<?php echo esc_url($monalisa_pricing_btn_link);?>" class="btn-light-bg"><?php echo esc_html($monalisa_pricing_btn_text);?></a>
									</div>
								</div><!-- END PRICING TABLE -->
							</div><!-- END COL -->
							
					<?php	}
					} else {
						// no posts found
					}

					// Restore original Post Data
					wp_reset_postdata();
				?>

		</div><!--END  ROW  -->
	</div><!-- END CONTAINER  -->
</section>
<!-- END PRICING -->
		
<?php 
  return ob_get_clean();
}
add_shortcode ('pricing_area', 'monalisa_pricing_area' );

//Testimonials Area
function monalisa_testimonials_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
			'section_title' => 'Our <span>Clients</span> Say',                                                                                                                                                                                                         
			'section_subtitle' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.',                                                                                                                                                                                                                                                                                                                                                                                                                 
                                               
		), $atts )
    );
ob_start();
?>

<!--- START TESTIMONIAL -->		
<section class="testimonials">
	<div class="container">
		<div class="row">
			<div class="section-title text-center wow zoomIn">
				<h2><?php echo monalisa_wp_kses($section_title);?></h2>
				<div class="line"></div>
				<p><?php echo monalisa_wp_kses($section_subtitle);?></p>
			</div>
			<div class="col-md-10 col-md-offset-1 col-sm-12 col-xs-12">
				<div class="flexslider testi-slider">
					<ul class="slides">
					
						<?php 
							// WP_Query arguments
							$args = array(
								'post_type'              => array( 'testimonials' ),
								'posts_per_page'         => '-1',
							);

							// The Query
							$monalisa_testimonials_query = new WP_Query( $args );

							// The Loop
							if ( $monalisa_testimonials_query->have_posts() ) {
								while ( $monalisa_testimonials_query->have_posts() ) {
									$monalisa_testimonials_query->the_post();

									?>
									
										<li>
											<div class="testi-slider-item">
												<p> <?php the_content();?></p>
												<?php the_post_thumbnail('monalisa_image_200_200', array('class' => '')); ?>
												<h6><?php the_title();?></h6>
											</div>
										</li><!--SINGLE SLIDE-->
							<?php	}
							} else {
								// no posts found
							}

							// Restore original Post Data
							wp_reset_postdata();

						?>					
					</ul><!--- END SLIDES -->
				</div><!--- END FLEXSLIDER -->
			</div><!--- END CONTAINER -->
		</div><!--- END CONTAINER -->
	</div><!--- END CONTAINER -->		       
</section>
<!--- END TESTIMONIAL -->
		
<?php 
  return ob_get_clean();
}
add_shortcode ('testimonials_area', 'monalisa_testimonials_area' );

//Blog Area
function monalisa_blog_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(
			'section_title' => 'Fresh <span>News</span>',                                                                                                                                                                                                         
			'section_subtitle' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.',                                                                                                                                                                                                                                                                                                                                                                                                                 
			'number_of_post' => '2',                                                                                                                                                                                                                                                                                                                                                                                                                 
                                               
		), $atts )
    );
ob_start();
?>

		<!-- START BLOG -->
		<section id="blog" class="our_blog section-padding">
			<div class="container">		
				<div class="row">
					<div class="section-title text-center wow zoomIn">
						<h2><?php echo monalisa_wp_kses($section_title);?></h2>
						<div class="line"></div>
						<p><?php echo monalisa_wp_kses($section_subtitle);?></p>
					</div>	
					
						<?php
							// WP_Query arguments
							$args = array(
								'post_type'              => array( 'post' ),
								'posts_per_page'         => $number_of_post,
							);

							// The Query
							$monalisa_blog_query = new WP_Query( $args );

							// The Loop
							if ( $monalisa_blog_query->have_posts() ) {
								while ( $monalisa_blog_query->have_posts() ) {
									$monalisa_blog_query->the_post(); ?>
									
										<div class="col-md-6 col-sm-6 col-xs-12 wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.1s" data-wow-offset="0">
											<div class="single-blog">
												<div class="single-img">
													<?php the_post_thumbnail('monalisa_image_1200_800', array('class' => 'img-responsive')); ?>
													<?php if(has_post_thumbnail()){ ?>
													<div class="post-date">
														<h4><?php echo esc_html(get_the_time('d F , Y'));?></h4>
													</div>

														<div class="blog-social">
															<h4><?php esc_html_e('Share On' , 'monalisa');?></h4>
															<?php
																$permalink = get_permalink(get_the_ID());
																$title = get_the_title();
															?>
															<ul>
	
																<li><a onClick="window.open('http://www.facebook.com/sharer.php?u=<?php echo esc_url($permalink) ;?>','Facebook','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" href="http://www.facebook.com/sharer.php?u=<?php echo esc_url($permalink) ;?>"><i class="fa fa-facebook facebook"></i></a></li>
																<li><a onClick="window.open('http://twitter.com/share?url=<?php echo esc_url($permalink) ;?>&amp;text=<?php echo esc_attr($title) ;?>','Twitter share','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" href="http://twitter.com/share?url=<?php echo esc_url($permalink) ;?>&amp;text=<?php echo esc_attr(str_replace(" ", "%20", $title)) ; ?>"><i class="fa fa-twitter twitter"></i></a></li>
																<li><a onClick="window.open('https://plus.google.com/share?url=<?php echo esc_url($permalink) ;?>','Google plus','width=585,height=666,left='+(screen.availWidth/2-292)+',top='+(screen.availHeight/2-333)+''); return false;" href="https://plus.google.com/share?url=<?php echo esc_url($permalink) ;?>"><i class="fa fa-google-plus google"></i></a></li>	
																<li><a onClick="window.open('http://www.linkedin.com/shareArticle?url=<?php echo esc_url($permalink) ;?>&title=<?php echo esc_attr($title) ;?>','Linkedin','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" href="http://www.linkedin.com/shareArticle?url=<?php echo esc_url($permalink) ;?>&title=<?php echo esc_attr($title) ;?>"><i class="fa fa-linkedin linkedin"></i></a></li>
															</ul>	
														</div>
													<?php } ?>			
												</div>	
												<div class="single_blog_dsc">
													<h3><?php the_title();?></h3>
													<p><?php monalisa_readmore_content(27);?></p>
													<a href="<?php the_permalink();?>"><?php esc_html_e('Read More' , 'monalisa');?></a>
												</div>
											</div>
										</div><!-- END COL -->	
							<?php	}
							} else {
								// no posts found
							}

							// Restore original Post Data
							wp_reset_postdata();
						?>					
	
				</div><!-- END ROW -->
			</div><!-- END CONTAINER -->
		</section>
		<!-- END BLOG -->
		
<?php 
  return ob_get_clean();
}
add_shortcode ('blog_area', 'monalisa_blog_area' );

//Clients Area
function monalisa_clients_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(                                                                                                                                                                                                                                                                                                                                                                                                               
                                               
		), $atts )
    );
ob_start();
?>
		<!-- START COMPANY PARTNER LOGO  -->
		<div class="partner-logo section-padding">
			<div class="partner_overlay">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="partner  wow fadeInRight">
								<?php
									// WP_Query arguments
									$args = array(
										'post_type'              => array( 'clients' ),
										'posts_per_page'         => '-1',
									);

									// The Query
									$monalisa_client_query = new WP_Query( $args );

									// The Loop
									if ( $monalisa_client_query->have_posts() ) {
										while ( $monalisa_client_query->have_posts() ) {
											$monalisa_client_query->the_post();
											$monalisa_client_link = get_post_meta(get_the_ID(), '_monalisa_client_web_url', true);
											?>
											
											<a href="<?php echo esc_url($monalisa_client_link);?>"><?php the_post_thumbnail('monalisa_image_210_90', array('class' => '')); ?></a>
									<?php	}
									} else {
										// no posts found
									}

									// Restore original Post Data
									wp_reset_postdata();
								?>							
						    	
		
							</div>
						</div><!-- END COL  -->
					</div><!--END  ROW  -->
				</div><!-- END CONTAINER  -->
			</div><!-- END OVERLAY -->
		</div>
		<!-- END COMPANY PARTNER LOGO -->
		
<?php 
  return ob_get_clean();
}
add_shortcode ('clients_area', 'monalisa_clients_area' );

//Contact Us Area
function monalisa_contact_us_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(                                                                                                                                                                                                                                                                                                                                                                                                               
               'section_title' => 'Get in <span>Touch</span>',                                
               'section_subtitle' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed eiusmod tempor enim minim veniam quis notru exercit ation Lorem ipsum dolor sit amet.',                                
               'cont7_shortcode_id' => '',                                
		), $atts )
    );
ob_start();
?>
		<!-- START CONTACT FORM AND CONTACT ADDRESS-->
		<section id="contact" class="contact_area section-padding">
			<div class="container">	
				<div class="row">
					<div class="section-title text-center wow zoomIn">
						<h2><?php echo monalisa_wp_kses($section_title);?></h2>
						<div class="line"></div>
						<p><?php echo monalisa_wp_kses($section_subtitle);?></p>
					</div>
					
					<div class="col-md-4 col-sm-4 col-xs-12">
						<?php echo do_shortcode($content);?>
					</div><!-- END COL -->	
					
					<div class="col-md-8 col-sm-8 col-xs-12 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.1s" data-wow-offset="0">
						<div class="contact">
							<?php echo do_shortcode('[contact-form-7 id="'.esc_attr($cont7_shortcode_id).'"]');?>
						</div>
					</div><!-- END COL -->
				</div><!--- END ROW -->				
			</div><!--- END CONTAINER -->				
		</section>
		<!-- END CONTACT FORM AND CONTACT ADDRESS -->
<?php 
  return ob_get_clean();
}
add_shortcode ('contact_us_area', 'monalisa_contact_us_area' );

//Contact Info
function monalisa_contact_info( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(                                                                                                                                                                                                                                                                                                                                                                                                               
               'cont_icon' => 'fa fa-envelope',                                                            
               'cont_title' => 'Email Address',                                                            
               'cont_info' => 'info@monalisa.com<br>admin@monalisa.com',                                                            
		), $atts )
    );
ob_start();
?>
	<div class="single-address wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.1s" data-wow-offset="0">
		<div class="media">
			<div class="media-left">
				<i class="<?php echo esc_attr($cont_icon);?>"></i>
			</div>
			<div class="media-body text-left">
				<h2 class="media-heading"><?php echo esc_html($cont_title);?></h2>
				<p><?php echo monalisa_wp_kses($cont_info);?></p>
			</div>
		</div>
	</div>
<?php 
  return ob_get_clean();
}
add_shortcode ('contact_info', 'monalisa_contact_info' );

//Google Map
function monalisa_google_map( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
               'cont_api_key' => 'AIzaSyDwIQh7LGryQdDDi-A603lR8NqiF3R_ycA',                                                            
               'cont_latitude' => '40.7127837',                                                            
               'cont_longitude' => '-74.00594130000002',                                                            
		), $atts )
    );
ob_start();
?>
	<!-- START MAP -->
	<div id="map"></div>
	<!-- END MAP -->
	<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo esc_js($cont_api_key);?>"></script>
	<script>	
		/*START CONTACT MAP JS*/
		function initialize() {
		  var mapOptions = {
			zoom: 15,
			scrollwheel: false,
			center: new google.maps.LatLng(<?php echo esc_js($cont_latitude);?>, <?php echo esc_js($cont_longitude);?>)
		  };
		  var map = new google.maps.Map(document.getElementById('map'),
			  mapOptions);
		  var marker = new google.maps.Marker({
			position: map.getCenter(),
			icon: '<?php echo esc_url(get_template_directory_uri());?>/assets/img/map_pin.png',
			map: map
		  });
		}
		google.maps.event.addDomListener(window, 'load', initialize);	
	   /*END CONTACT MAP JS*/	
	</script>	
<?php 
  return ob_get_clean();
}
add_shortcode ('google_map', 'monalisa_google_map' );


//Shortcode Importer
function monalisa_shortcode_importer( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(                                   
            'enter_shortcode' => '',                                                                              

		), $atts )
    );

	echo do_shortcode($enter_shortcode);
}
add_shortcode ('shortcode_importer', 'monalisa_shortcode_importer' );
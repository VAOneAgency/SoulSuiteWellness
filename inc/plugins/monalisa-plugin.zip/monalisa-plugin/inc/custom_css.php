<?php 
function monalisa_movers_custom_css(){
	global $monalisa;
	
	if(!is_admin()) :
	?>
  
	<?php 
	
		$monalisa_menu_text_color						 = '';
		$monalisa_menu_text_hover_acive_color						 = '';
		$monalisa_sticky_menu_bg_color						 = '';
		$monalisa_sticky_menu_text_color						 = '';
		$monalisa_sticky_menu_text_hover_acive_color						 = '';
		$monalisa_footer_bg_color						 = '';
		$monalisa_footer_bottom_bg_color						 = '';
		$monalisa_footer_text_color						 = '';
		$monalisa_footer_link_color						 = '';
		$monalisa_spinner_image						 = '';
		$monalisa_spinner_bg_color						 = '';
		$monalisa_theme_color						 = '';
		$monalisa_css_editor						 = '';
		

		if ( isset( $monalisa['monalisa_menu_text_color'] ) ) {
			$monalisa_menu_text_color = $monalisa['monalisa_menu_text_color'];
		}		
		if ( isset( $monalisa['monalisa_menu_text_hover_acive_color'] ) ) {
			$monalisa_menu_text_hover_acive_color = $monalisa['monalisa_menu_text_hover_acive_color'];
		}			
		if ( isset( $monalisa['monalisa_sticky_menu_bg_color'] ) ) {
			$monalisa_sticky_menu_bg_color = $monalisa['monalisa_sticky_menu_bg_color'];
		}		
		if ( isset( $monalisa['monalisa_sticky_menu_text_color'] ) ) {
			$monalisa_sticky_menu_text_color = $monalisa['monalisa_sticky_menu_text_color'];
		}			
		if ( isset( $monalisa['monalisa_sticky_menu_text_hover_acive_color'] ) ) {
			$monalisa_sticky_menu_text_hover_acive_color = $monalisa['monalisa_sticky_menu_text_hover_acive_color'];
		}	
	
		if ( isset( $monalisa['monalisa_footer_bg_color'] ) ) {
			$monalisa_footer_bg_color = $monalisa['monalisa_footer_bg_color'];
		}			
		
		if ( isset( $monalisa['monalisa_footer_text_color'] ) ) {
			$monalisa_footer_text_color = $monalisa['monalisa_footer_text_color'];
		}			

		if ( isset( $monalisa['monalisa_footer_link_color'] ) ) {
			$monalisa_footer_link_color = $monalisa['monalisa_footer_link_color'];
		}			
		if ( isset( $monalisa['monalisa_spinner_image'] ) ) {
			$monalisa_spinner_image = $monalisa['monalisa_spinner_image']['url'];
		}			
		
		if ( isset( $monalisa['monalisa_spinner_bg_color'] ) ) {
			$monalisa_spinner_bg_color = $monalisa['monalisa_spinner_bg_color'];
		}		

		if ( isset( $monalisa['monalisa_theme_color'] ) ) {
			$monalisa_theme_color = $monalisa['monalisa_theme_color'];
		}	
		if ( isset( $monalisa['monalisa_css_editor'] ) ) {
			$monalisa_css_editor = $monalisa['monalisa_css_editor'];
		}
	

	wp_enqueue_style( 'monalisa-custom-css', get_template_directory_uri() . '/assets/css/custom-style.css' );
	
	//add custom css
	$monalisa_custom_css = "

		.preloader {
			background: {$monalisa_spinner_bg_color};
		}			
		
		.status {
			background-image: url($monalisa_spinner_image);
			background-repeat: no-repeat;
		}			
		
		.menu-top li a {
			color: {$monalisa_menu_text_color}!important;
		}		
		
		.menu-top li a:hover {
			color: {$monalisa_menu_text_hover_acive_color}!important;
		}		
		
		.navbar-default.menu-shrink {
			background: {$monalisa_sticky_menu_bg_color};
		}		
		.navbar-default.menu-shrink li a {
			color: {$monalisa_sticky_menu_text_color}!important;
		}	
		.navbar-default.menu-shrink li a:hover{
			color: {$monalisa_sticky_menu_text_hover_acive_color} !important;
		}		
		
		.footer{
			background: {$monalisa_footer_bg_color};
		}		
		.footer_copyright{
			color: {$monalisa_footer_text_color};
		}		
		.footer_copyright a{
			color: {$monalisa_footer_link_color};
		}		
		
		.single_offer h5,
		.section-title h2 span,
		.testimonials .flexslider .testi-slider-item h6,
		.single_blog_dsc a,
		.about-us-content h2 span,
		.time_counter,
		.opening_hour ul li span,
		.offer a:hover, .offer a:focus,
		.btn-feature-bg:hover,
		.btn-feature-bg:focus,
		.tab-bar-inner .nav-tabs > li.active > a, 
		.tab-bar-inner .nav-tabs > li.active > a:focus, 
		.tab-bar-inner .nav-tabs > li.active > a:hover,
		.woocommerce div.product p.price, 
		.woocommerce div.product span.price	,
		a	
		{
			color: {$monalisa_theme_color};
		}
		.woocommerce div.product p.price,
		.woocommerce div.product span.price	{
			color: {$monalisa_theme_color}!important;
		}
		.offer a:hover, .offer a:focus,
		.btn-feature-bg:hover,
		.btn-feature-bg:focus,
		.testimonials .flexslider .testi-slider-item img,
		.btn-portfolio-bg,
		.pricing-btn a
			{
			border-color: {$monalisa_theme_color};
		}
		
		.single-address i,
		.about-line,
		.topcontrol,
		.btn-contact-bg,
		.btn-light-bg,
		.btn-light-bg-two:hover, 
		.btn-light-bg-two:focus,
		.single_feature i,
		.btn-portfolio-bg,
		.video-container a:hover .play-video,
		.woocommerce span.onsale,
		.add_to_cat_btn button, 
		.woocommerce a.added_to_cart, 
		.continue-shopping.button, 
		.button.empty-cart, 
		.button.update, 
		.button.apply-coupon, 
		.checkout-button.button.alt.wc-forward, 
		#place_order, 
		.form-row.form-row-last .button, 
		.woocommerce .widget_price_filter .price_slider_amount .button, 
		.shipping-calculator-form .button, 
		form.login .button, 
		form.lost_reset_password .button, 
		#review_form_wrapper #submit,
		.woocommerce div.product form.cart .button,
		.line,
		.partner-logo,
		.testimonials .flex-direction-nav a,
		.color-two,
		.pricing-btn a,
		.woocommerce .widget_price_filter .ui-slider .ui-slider-handle, 
		.woocommerce .widget_price_filter .ui-slider .ui-slider-range{
			background: {$monalisa_theme_color};
		}			
		.woocommerce .product-new, .add_to_cat_btn button, .woocommerce a.added_to_cart, .continue-shopping.button, .button.empty-cart, .button.update, .button.apply-coupon, .checkout-button.button.alt.wc-forward, #place_order, .form-row.form-row-last .button, .woocommerce .widget_price_filter .price_slider_amount .button, .shipping-calculator-form .button, form.login .button, form.lost_reset_password .button, #review_form_wrapper #submit{
			background: {$monalisa_theme_color}!important;
		}
		{$monalisa_css_editor};
	";
	
	//Add the above custom CSS via wp_add_inline_style
	wp_add_inline_style( 'monalisa-custom-css', $monalisa_custom_css ); //Pass the variable into the main style sheet ID
	
	
  endif;
}

add_action( 'wp_enqueue_scripts', 'monalisa_movers_custom_css'  ) ;
<?php

if ( ! function_exists('monalisa_gallery') ) {

// Register Custom Post Type
function monalisa_gallery() {

	$labels = array(
		'name'                  => esc_html_x( 'Galleries', 'Post Type General Name', 'monalisa' ),
		'singular_name'         => esc_html_x( 'Gallery', 'Post Type Singular Name', 'monalisa' ),
		'menu_name'             => esc_html__( 'Gallery', 'monalisa' ),
		'name_admin_bar'        => esc_html__( 'Gallery', 'monalisa' ),
		'archives'              => esc_html__( 'Item Archives', 'monalisa' ),
		'attributes'            => esc_html__( 'Item Attributes', 'monalisa' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'monalisa' ),
		'all_items'             => esc_html__( 'All Items', 'monalisa' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'monalisa' ),
		'add_new'               => esc_html__( 'Add New', 'monalisa' ),
		'new_item'              => esc_html__( 'New Item', 'monalisa' ),
		'edit_item'             => esc_html__( 'Edit Item', 'monalisa' ),
		'update_item'           => esc_html__( 'Update Item', 'monalisa' ),
		'view_item'             => esc_html__( 'View Item', 'monalisa' ),
		'view_items'            => esc_html__( 'View Items', 'monalisa' ),
		'search_items'          => esc_html__( 'Search Item', 'monalisa' ),
		'not_found'             => esc_html__( 'Not found', 'monalisa' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'monalisa' ),
		'featured_image'        => esc_html__( 'Featured Image', 'monalisa' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'monalisa' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'monalisa' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'monalisa' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'monalisa' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'monalisa' ),
		'items_list'            => esc_html__( 'Items list', 'monalisa' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'monalisa' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'monalisa' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Gallery', 'monalisa' ),
		'description'           => esc_html__( 'Post Type Description', 'monalisa' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'thumbnail', ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-camera',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'gallery', $args );

}
add_action( 'init', 'monalisa_gallery', 0 );

}

if ( ! function_exists('monalisa_features') ) {

// Register Custom Post Type
function monalisa_features() {

	$labels = array(
		'name'                  => esc_html_x( 'Freatures', 'Post Type General Name', 'monalisa' ),
		'singular_name'         => esc_html_x( 'Freature', 'Post Type Singular Name', 'monalisa' ),
		'menu_name'             => esc_html__( 'Freatures', 'monalisa' ),
		'name_admin_bar'        => esc_html__( 'Freatures', 'monalisa' ),
		'archives'              => esc_html__( 'Item Archives', 'monalisa' ),
		'attributes'            => esc_html__( 'Item Attributes', 'monalisa' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'monalisa' ),
		'all_items'             => esc_html__( 'All Items', 'monalisa' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'monalisa' ),
		'add_new'               => esc_html__( 'Add New', 'monalisa' ),
		'new_item'              => esc_html__( 'New Item', 'monalisa' ),
		'edit_item'             => esc_html__( 'Edit Item', 'monalisa' ),
		'update_item'           => esc_html__( 'Update Item', 'monalisa' ),
		'view_item'             => esc_html__( 'View Item', 'monalisa' ),
		'view_items'            => esc_html__( 'View Items', 'monalisa' ),
		'search_items'          => esc_html__( 'Search Item', 'monalisa' ),
		'not_found'             => esc_html__( 'Not found', 'monalisa' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'monalisa' ),
		'featured_image'        => esc_html__( 'Featured Image', 'monalisa' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'monalisa' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'monalisa' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'monalisa' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'monalisa' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'monalisa' ),
		'items_list'            => esc_html__( 'Items list', 'monalisa' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'monalisa' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'monalisa' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Freature', 'monalisa' ),
		'description'           => esc_html__( 'Post Type Description', 'monalisa' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'thumbnail', ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-megaphone',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'feature', $args );

}
add_action( 'init', 'monalisa_features', 0 );

}

if ( ! function_exists('monalisa_team') ) {

// Register Custom Post Type
function monalisa_team() {

	$labels = array(
		'name'                  => esc_html_x( 'Team', 'Post Type General Name', 'monalisa' ),
		'singular_name'         => esc_html_x( 'Team', 'Post Type Singular Name', 'monalisa' ),
		'menu_name'             => esc_html__( 'Team', 'monalisa' ),
		'name_admin_bar'        => esc_html__( 'Team', 'monalisa' ),
		'archives'              => esc_html__( 'Item Archives', 'monalisa' ),
		'attributes'            => esc_html__( 'Item Attributes', 'monalisa' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'monalisa' ),
		'all_items'             => esc_html__( 'All Items', 'monalisa' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'monalisa' ),
		'add_new'               => esc_html__( 'Add New', 'monalisa' ),
		'new_item'              => esc_html__( 'New Item', 'monalisa' ),
		'edit_item'             => esc_html__( 'Edit Item', 'monalisa' ),
		'update_item'           => esc_html__( 'Update Item', 'monalisa' ),
		'view_item'             => esc_html__( 'View Item', 'monalisa' ),
		'view_items'            => esc_html__( 'View Items', 'monalisa' ),
		'search_items'          => esc_html__( 'Search Item', 'monalisa' ),
		'not_found'             => esc_html__( 'Not found', 'monalisa' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'monalisa' ),
		'featured_image'        => esc_html__( 'Featured Image', 'monalisa' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'monalisa' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'monalisa' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'monalisa' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'monalisa' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'monalisa' ),
		'items_list'            => esc_html__( 'Items list', 'monalisa' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'monalisa' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'monalisa' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Team', 'monalisa' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'thumbnail', ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-groups',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'team', $args );

}
add_action( 'init', 'monalisa_team', 0 );

}

if ( ! function_exists('monalisa_pricing') ) {

// Register Custom Post Type
function monalisa_pricing() {

	$labels = array(
		'name'                  => esc_html_x( 'Pricing', 'Post Type General Name', 'monalisa' ),
		'singular_name'         => esc_html_x( 'Pricing', 'Post Type Singular Name', 'monalisa' ),
		'menu_name'             => esc_html__( 'Pricing', 'monalisa' ),
		'name_admin_bar'        => esc_html__( 'Pricing', 'monalisa' ),
		'archives'              => esc_html__( 'Item Archives', 'monalisa' ),
		'attributes'            => esc_html__( 'Item Attributes', 'monalisa' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'monalisa' ),
		'all_items'             => esc_html__( 'All Items', 'monalisa' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'monalisa' ),
		'add_new'               => esc_html__( 'Add New', 'monalisa' ),
		'new_item'              => esc_html__( 'New Item', 'monalisa' ),
		'edit_item'             => esc_html__( 'Edit Item', 'monalisa' ),
		'update_item'           => esc_html__( 'Update Item', 'monalisa' ),
		'view_item'             => esc_html__( 'View Item', 'monalisa' ),
		'view_items'            => esc_html__( 'View Items', 'monalisa' ),
		'search_items'          => esc_html__( 'Search Item', 'monalisa' ),
		'not_found'             => esc_html__( 'Not found', 'monalisa' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'monalisa' ),
		'featured_image'        => esc_html__( 'Featured Image', 'monalisa' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'monalisa' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'monalisa' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'monalisa' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'monalisa' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'monalisa' ),
		'items_list'            => esc_html__( 'Items list', 'monalisa' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'monalisa' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'monalisa' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Pricing', 'monalisa' ),
		'labels'                => $labels,
		'supports'              => array( 'title', ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-index-card',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'pricing', $args );

}
add_action( 'init', 'monalisa_pricing', 0 );

}

if ( ! function_exists('monalisa_testimonials') ) {

// Register Custom Post Type
function monalisa_testimonials() {

	$labels = array(
		'name'                  => esc_html_x( 'Testimonials', 'Post Type General Name', 'monalisa' ),
		'singular_name'         => esc_html_x( 'Testimonials', 'Post Type Singular Name', 'monalisa' ),
		'menu_name'             => esc_html__( 'Testimonials', 'monalisa' ),
		'name_admin_bar'        => esc_html__( 'Testimonials', 'monalisa' ),
		'archives'              => esc_html__( 'Item Archives', 'monalisa' ),
		'attributes'            => esc_html__( 'Item Attributes', 'monalisa' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'monalisa' ),
		'all_items'             => esc_html__( 'All Items', 'monalisa' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'monalisa' ),
		'add_new'               => esc_html__( 'Add New', 'monalisa' ),
		'new_item'              => esc_html__( 'New Item', 'monalisa' ),
		'edit_item'             => esc_html__( 'Edit Item', 'monalisa' ),
		'update_item'           => esc_html__( 'Update Item', 'monalisa' ),
		'view_item'             => esc_html__( 'View Item', 'monalisa' ),
		'view_items'            => esc_html__( 'View Items', 'monalisa' ),
		'search_items'          => esc_html__( 'Search Item', 'monalisa' ),
		'not_found'             => esc_html__( 'Not found', 'monalisa' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'monalisa' ),
		'featured_image'        => esc_html__( 'Featured Image', 'monalisa' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'monalisa' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'monalisa' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'monalisa' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'monalisa' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'monalisa' ),
		'items_list'            => esc_html__( 'Items list', 'monalisa' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'monalisa' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'monalisa' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Testimonials', 'monalisa' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-smiley',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'testimonials', $args );

}
add_action( 'init', 'monalisa_testimonials', 0 );

}

if ( ! function_exists('monalisa_client') ) {

// Register Custom Post Type
function monalisa_client() {

	$labels = array(
		'name'                  => esc_html_x( 'Clients', 'Post Type General Name', 'monalisa' ),
		'singular_name'         => esc_html_x( 'Clients', 'Post Type Singular Name', 'monalisa' ),
		'menu_name'             => esc_html__( 'Clients', 'monalisa' ),
		'name_admin_bar'        => esc_html__( 'Clients', 'monalisa' ),
		'archives'              => esc_html__( 'Item Archives', 'monalisa' ),
		'attributes'            => esc_html__( 'Item Attributes', 'monalisa' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'monalisa' ),
		'all_items'             => esc_html__( 'All Items', 'monalisa' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'monalisa' ),
		'add_new'               => esc_html__( 'Add New', 'monalisa' ),
		'new_item'              => esc_html__( 'New Item', 'monalisa' ),
		'edit_item'             => esc_html__( 'Edit Item', 'monalisa' ),
		'update_item'           => esc_html__( 'Update Item', 'monalisa' ),
		'view_item'             => esc_html__( 'View Item', 'monalisa' ),
		'view_items'            => esc_html__( 'View Items', 'monalisa' ),
		'search_items'          => esc_html__( 'Search Item', 'monalisa' ),
		'not_found'             => esc_html__( 'Not found', 'monalisa' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'monalisa' ),
		'featured_image'        => esc_html__( 'Featured Image', 'monalisa' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'monalisa' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'monalisa' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'monalisa' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'monalisa' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'monalisa' ),
		'items_list'            => esc_html__( 'Items list', 'monalisa' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'monalisa' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'monalisa' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Clients', 'monalisa' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'thumbnail', ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-nametag',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,		
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'clients', $args );

}
add_action( 'init', 'monalisa_client', 0 );

}
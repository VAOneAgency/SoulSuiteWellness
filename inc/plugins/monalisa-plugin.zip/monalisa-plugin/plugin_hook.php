<?php

/*

Plugin Name: Monalisa Plugin

Plugin URI: http://getmasum.net

Description: After install the Monalisa WordPress Theme, you must need to install this "Monalisa Plugin" first to get all functions of Monalisa WP Theme.

Author: Masum Billah

Author URI: http://www.getmasum.net

Version: 1.0.0

Text Domain: monalisa

*/


//define

define( 'MONALISAPLUGINDIR', dirname( __FILE__ ) ); 

// Add main files

include_once(MONALISAPLUGINDIR. '/inc/custom_posts.php');
include_once(MONALISAPLUGINDIR. '/inc/shortcodes.php');
include_once(MONALISAPLUGINDIR. '/inc/monalisa_metabox.php');
include_once(MONALISAPLUGINDIR. '/inc/theme-options.php');
include_once(MONALISAPLUGINDIR. '/inc/custom_css.php');